# OP Mod

![Logo](icon.png)

It's a [Mindustry](https://mindustrygame.github.io) mod.

~~That Means Oh PHUCK Mod, because yes~~

This mod add new stupidass blocks (and 3 ores) or upgraded(_~~sometimes stupidly op~~_) versions of vanilla blocks. BUT that doesn't mean it's a hack, i recommend downloading another mod that lets yuo use hidden/sandbox blocks and yeah, phucked up sheet

## CAUTION

This mod contains:

- Bad Sprites, many copying from [the source code](https://github.com/Anuken/Mindustry/blob/master/core/assets-raw/sprites/).
- Bad english (no thanks)
- Bad ideas, why.
- What do you want playing this? Why did you download this? Who's forcing you to download this? 

### Changelog

No. - Nero#2147
