require("serpulo");
require("checkUpdate");